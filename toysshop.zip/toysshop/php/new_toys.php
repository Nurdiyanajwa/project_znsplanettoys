<?php

if (isset($_POST["submit"])) {
    include_once("dbconnect.php");
    $name = $_POST["name"];
    $code = $_POST["code"];
    $price = $_POST["price"];
    $description = $_POST["description"];
    $type = $_POST["type"];
    $brand = $_POST["brand"];
    $qty = $_POST["qty"];
    $ages = $_POST["ages"];
    $sqlinsert = "INSERT INTO `tbl_toys`(`toy_name`, `toy_code`, `toy_price`, `toy_description`, `toy_type`, `toy_brand`, `toy_qty`, `toy_ages`) VALUES ('$name', '$code', $price, '$description', '$type', '$brand','$qty','$ages')";

    try {
        $conn->exec($sqlinsert);
        if (file_exists($_FILES["fileToUpload"]["tmp_name"]) || is_uploaded_file($_FILES["fileToUpload"]["tmp_name"])) {
            uploadImage($code);
        }
        echo "<script>alert('Registration successful')</script>";
        echo "<script>window.location.replace('new_toys.php')</script>";
    } catch (PDOException $e) {
        echo "<script>alert('Registration failed')</script>";
        echo "<script>window.location.replace('new_toys.php')</script>";
    }
}

function uploadImage($code)
{
    $target_dir = "../images/toys/";
    $target_file = $target_dir . $code . ".jpg";
    move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
}

?>

<!DOCTYPE html>
<html>
<title>ZNS Planet Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
<link rel="stylesheet" type="text/css" href="../css/style.css">
<script src="../js/script.js"></script>

<body>

    <!-- Sidebar (hidden by default) -->
    <nav class="w3-sidebar w3-bar-block w3-card w3-top w3-xlarge w3-animate-left w3-teal" style="display:none;z-index:2;width:40%;min-width:300px" id="mySidebar">
        <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button">Close Menu</a>
        <a href="#index.php" onclick="w3_close()" class="w3-bar-item w3-button">Toys</a>
        <a href="#mycart.php" onclick="w3_close()" class="w3-bar-item w3-button">My Carts</a>
        <a href="#paymenthist" onclick="w3_close()" class="w3-bar-item w3-button">Payment History</a>
        <a href="#about" onclick="w3_close()" class="w3-bar-item w3-button">About</a>
    </nav>

    <!-- Top menu -->
    <div class="w3-top">
        <div class="w3-white w3-xlarge" style="max-width:1200px;margin:auto">
            <div class="w3-button w3-padding-16 w3-left" onclick="w3_open()">☰</div>
            <div class="w3-right w3-padding-16">Mail</div>
            <div class="w3-center w3-padding-16">ZNS Planet Toys</div>
        </div>
    </div>
    <div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:100px">

        <form class="w3-container w3-padding" action="new_toys.php" method="post" enctype="multipart/form-data" onsubmit="return confirmDialog()">
            <div class="w3-container w3-teal">
                <h2>New Toys</h2>
            </div>

            <div class="w3-container w3-border w3-center w3-padding">
                <img class="w3-image w3-round w3-margin" src="../images/iron man.jpg" style="height:100%; width:100%; max-width:330px"><br>
                <input type="file" onchange="previewFile()" name="fileToUpload" id="fileToUpload"><br>
            </div>
            <br>
            <label>Toys Name</label>
            <input class="w3-input" name="name" id="idname" type="text" required>

            <label>Code </label>
            <input class="w3-input" type="text" name="code" id="idcode" required>

            <label>Price</label>
            <input class="w3-input" type="number" name="price" id="idprice" step="any" required>

            <p>
                <label>Description</label>
                <textarea class="w3-input w3-border" name="description" id="iddesc" rows="4" cols="50" width="100%" placeholder="Toy Description" required></textarea>
            </p>

            <label>Type</label>
            <input class="w3-input" type="text" name="type" id="idtype" required>

            <label>Brand</label>
            <input class="w3-input" type="text" name="brand" id="idbrand" required>
            <p>
                <select class="w3-select" name="ages" id="idages" required>
                    <option value="" disabled selected>Choose ages</option>
                    <option value="2-3 years">2-3 years </option>
                    <option value="4-5 years">4-5 years</option>
                    <option value="6-8 years">6-8 years</option>
                    <option value="9 years above">9 years above</option>
                </select>
            </p>
            <div class="row">
                <input class="w3-input w3-border w3-block  w3-round w3-teal" type="submit" name="submit" value="Submit">
            </div>

        </form>

    </div>
    <footer class="w3-row-padding w3-padding-32">
        <hr>
        </hr>
        <p class="w3-center">ZNS Planet Toys&reg; </p>
    </footer>


</body>

</html>