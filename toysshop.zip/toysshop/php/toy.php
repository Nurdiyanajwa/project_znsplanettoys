<?php

class Toy{
    public $toyid,$toy_name,$toy_code,$toy_price,$toy_description,$toy_type,$toy_brand,$toy_ages,$toy_date;
    
}

?>